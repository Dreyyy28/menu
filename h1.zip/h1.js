// Produk data
const foods = [
  { name: "Siomay", price: 12000, image: "https://asset.kompas.com/crops/Nru6WNgEHqEe1ttSn9rmSCdeMs4=/0x0:1000x667/750x500/data/photo/2021/05/23/60aa371ed27a5.jpg" },
  { name: "Pempek", price: 12000, image: "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcTldpVQmtqKEm_n2tgkNIaGzQhP9W36NBiuEg&s" },
  { name: "Pecel", price: 18000, image: "https://www.frisianflag.com/storage/app/media/uploaded-files/pecel-sayur-sederhana.jpg" },
  { name: "Ayam Bakar", price: 14000, image: "https://awsimages.detik.net.id/community/media/visual/2023/02/06/1385476906_169.jpeg?w=600&q=90" },
];

const drinks = [
  { name: "Es Teh", price: 5000, image: "https://asset.kompas.com/crops/9iB_ruTEMU7otPYnbCNVng8zhrQ=/0x0:4939x3293/1200x800/data/photo/2022/09/25/63300cfd403f0.jpg" },
  { name: "Es Jeruk", price: 8000, image: "https://cdn.manisdansedap.com/img_thumb_list/2023/06/22-es-jeruk-peras-manis_8_6493cfdea8732.jpg" },
  { name: "Es Kuwut", price: 9000, image: "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcRU7czd4SS1c5xDI00Wtu9eE8b7K4OyuqCing&s" },
  { name: "Es Sirup", price: 10000, image: "https://png.pngtree.com/png-clipart/20240711/original/pngtree-fresh-jumbo-syrup-ice-png-image_15539278.png" },
];

const snacks = [
  { name: "Dimsum", price: 16000, image: "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQ_zGv3nkWilcREAW4Buz3JP43FWqmiSrW19Q&s" },
  { name: "Udang Rambutan", price: 10000, image: "https://cdn0-production-images-kly.akamaized.net/6NKXKjsxO1qbOcW-CJ_oBwQFll0=/0x40:999x603/1200x675/filters:quality(75):strip_icc():format(jpeg)/kly-media-production/medias/4521161/original/093588100_1690860332-shutterstock_2234327421.jpg" },
  { name: "Risol Mayo", price: 8000, image: "hhttps://puripangan.co.id/wp-content/uploads/2023/07/Risol-Mayo-Klasik-1200x900-cropped.jpg" },
  { name: "Cireng", price: 7000, image: "https://i.pinimg.com/736x/08/b3/b9/08b3b912329d25d195672d3be2a5cdcd.jpg" },
];

let cart = [];

function renderProducts() {
  const foodList = document.getElementById("food-list");
  const drinkList = document.getElementById("drink-list");
  const snackList = document.getElementById("snack-list");

  foods.forEach((item) => foodList.appendChild(createCard(item, true)));
  drinks.forEach((item) => drinkList.appendChild(createCard(item, false)));
  snacks.forEach((item) => snackList.appendChild(createCard(item, true)));
}

function createCard(item, withOption) {
  const card = document.createElement("div");
  card.className = "product-card overlay-bg";

  const optionHTML = withOption
    ? item.name.toLowerCase() === "dimsum"
      ? `<label class="option-label">Jenis:</label><select class="option-select"><option value="Biasa">Biasa</option><option value="Mentai">Mentai</option><option value="Chili Oil">Chili Oil</option></select>`
      : `<label class="option-label">Kepedasan:</label><select class="option-select"><option value="Tidak Pedas">Tidak Pedas</option><option value="Pedas">Pedas</option></select>`
    : "";

  card.innerHTML = `
    <img src="${item.image}" alt="${item.name}">
    <div class="product-card-content">
      <h3>${item.name}</h3>
      <p class="price">Rp ${item.price.toLocaleString('id-ID')}</p>
      ${optionHTML}
      <button class="add-button">+ Tambah</button>
    </div>
  `;

  const button = card.querySelector(".add-button");
  const option = card.querySelector("select");
  button.addEventListener("click", () => {
    const variant = option ? option.value : "";
    addToCart(item, variant);
    showToast(`${item.name}${variant ? ` (${variant})` : ""} ditambahkan!`);
  });

  return card;
}

function addToCart(item, variant) {
  const key = `${item.name}-${variant}`;
  const existing = cart.find((c) => c.key === key);

  if (existing) {
    existing.qty++;
  } else {
    cart.push({ key, name: item.name, variant, price: item.price, qty: 1 });
  }
  updateCheckout();
}

function updateCheckout() {
  const container = document.getElementById("checkout-items");
  const totalBox = document.getElementById("checkout-total");
  container.innerHTML = "";
  let total = 0;

  cart.forEach((item, i) => {
    total += item.qty * item.price;
    const div = document.createElement("div");
    div.className = "cart-item overlay-bg";
    div.innerHTML = `
      <span class="item-name">🍽️ ${item.name}${item.variant ? ` (${item.variant})` : ""}</span>
      <span class="item-price">Rp ${item.price.toLocaleString('id-ID')}</span>
      <span class="item-qty">x ${item.qty}</span>
      <button class="remove-button" onclick="removeItem(${i})">❌</button>
    `;
    container.appendChild(div);
  });

  totalBox.textContent = `Rp ${total.toLocaleString('id-ID')}`;
}

function removeItem(index) {
  cart.splice(index, 1);
  updateCheckout();
}

function showToast(message) {
  const toast = document.getElementById("toast");
  toast.textContent = message;
  toast.classList.add("show");
  setTimeout(() => toast.classList.remove("show"), 3000);
}

// Handle checkout
const form = document.getElementById("checkout-form");
form.addEventListener("submit", function (e) {
  e.preventDefault();

  const name = document.getElementById("customer-name").value;
  const address = document.getElementById("customer-address").value;
  const method = document.querySelector("input[name='method']:checked")?.value || "";

  if (cart.length === 0) {
    alert("Keranjang masih kosong!");
    return;
  }

  const today = new Date();
  const date = today.toLocaleDateString('id-ID', { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric' });

  let message = `🛒 *Pesanan Baru*%0A`;
  cart.forEach((item) => {
    message += `- ${item.name}${item.variant ? ` (${item.variant})` : ""} x ${item.qty}%0A`;
  });
  message += `%0A👤 Nama: ${name}%0A📍 Alamat: ${address}%0A🛵 Metode: ${method}%0A📅 Tanggal: ${date}`;

  const phone = "6281234567890";
  const waUrl = `https://wa.me/${phone}?text=${encodeURIComponent(message)}`;
  window.open(waUrl, '_blank');
});

// Inisialisasi
window.addEventListener("DOMContentLoaded", renderProducts);
